# Assets Directory

This directory contains images, icons, and other static assets for the LocalLink website.

## Contents
- `favicon.ico` - Website favicon
- `images/` - Image assets
- `icons/` - Custom icon files
- `uploads/` - User uploaded content (profile pictures, etc.)

## Image Guidelines
- Profile pictures: 150x150px, JPG/PNG
- Skill images: 300x200px, JPG/PNG
- Logo variations: SVG preferred
- Icons: 24x24px or 32x32px SVG/PNG

## Optimization
- Compress images for web
- Use WebP format when possible
- Lazy load images below the fold
- Provide alt text for accessibility
