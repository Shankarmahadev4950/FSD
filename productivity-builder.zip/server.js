const fastify = require('fastify')({ logger: true });

// Register plugins
fastify.register(require('@fastify/cors'), {
    origin: process.env.FRONTEND_URL || 'http://localhost:8000'
});

fastify.register(require('@fastify/jwt'), {
    secret: process.env.JWT_SECRET || 'your-secret-key-change-in-production'
});

// Health check route
fastify.get('/api/health', async (request, reply) => {
    return { status: 'OK', message: 'LocalLink API is running' };
});

// Start server
const start = async () => {
    try {
        await fastify.listen({ 
            port: process.env.PORT || 5000,
            host: '0.0.0.0'
        });
        console.log('🚀 LocalLink API server running on port', process.env.PORT || 5000);
    } catch (err) {
        fastify.log.error(err);
        process.exit(1);
    }
};

start();
