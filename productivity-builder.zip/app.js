// Custom Productivity Tool Builder JavaScript

class ProductivityToolBuilder {
    constructor() {
        this.currentTool = {
            id: 'new-tool',
            name: 'Untitled Tool',
            components: [],
            created: new Date().toISOString()
        };
        this.selectedComponent = null;
        this.draggedComponent = null;
        this.history = [];
        this.historyIndex = -1;
        this.zoomLevel = 100;
        this.tempComponentProps = {};
        
        this.componentDefinitions = {
            'pomodoro-timer': {
                name: 'Pomodoro Timer',
                icon: '⏰',
                defaultProps: {
                    workDuration: 25,
                    breakDuration: 5,
                    longBreakDuration: 15,
                    sessionsUntilLongBreak: 4,
                    autoStart: false,
                    soundEnabled: true
                }
            },
            'countdown-timer': {
                name: 'Countdown Timer',
                icon: '⏱️',
                defaultProps: {
                    duration: 30,
                    unit: 'minutes',
                    autoReset: false,
                    soundEnabled: true
                }
            },
            'focus-timer': {
                name: 'Focus Timer',
                icon: '🎯',
                defaultProps: {
                    duration: 45,
                    breakReminder: true,
                    blockingSites: [],
                    focusMusic: false
                }
            },
            'todo-list': {
                name: 'To-Do List',
                icon: '✅',
                defaultProps: {
                    maxTasks: 20,
                    showCompleted: true,
                    sortBy: 'manual',
                    categories: []
                }
            },
            'kanban-board': {
                name: 'Kanban Board',
                icon: '📋',
                defaultProps: {
                    columns: ['To Do', 'In Progress', 'Done'],
                    maxCardsPerColumn: 10,
                    colorCoding: true
                }
            },
            'priority-matrix': {
                name: 'Priority Matrix',
                icon: '📊',
                defaultProps: {
                    quadrants: ['Urgent & Important', 'Not Urgent & Important', 'Urgent & Not Important', 'Not Urgent & Not Important'],
                    maxTasksPerQuadrant: 5
                }
            },
            'habit-tracker': {
                name: 'Habit Tracker',
                icon: '📅',
                defaultProps: {
                    habits: ['Exercise', 'Read', 'Meditate'],
                    viewType: 'calendar',
                    streakDisplay: true,
                    weekStart: 'monday'
                }
            },
            'streak-counter': {
                name: 'Streak Counter',
                icon: '🔥',
                defaultProps: {
                    habitName: 'Daily Exercise',
                    currentStreak: 0,
                    longestStreak: 0,
                    targetStreak: 30
                }
            },
            'progress-bar': {
                name: 'Progress Bar',
                icon: '📈',
                defaultProps: {
                    goalName: 'Read 50 Books',
                    currentValue: 0,
                    targetValue: 50,
                    unit: 'books',
                    showPercentage: true
                }
            },
            'text-block': {
                name: 'Text Block',
                icon: '📝',
                defaultProps: {
                    text: 'Enter your text here',
                    fontSize: 16,
                    textAlign: 'left',
                    fontWeight: 'normal'
                }
            },
            'container': {
                name: 'Container',
                icon: '📦',
                defaultProps: {
                    padding: 16,
                    borderRadius: 8,
                    backgroundColor: '#ffffff',
                    borderWidth: 1
                }
            },
            'button': {
                name: 'Button',
                icon: '🔘',
                defaultProps: {
                    text: 'Click me',
                    action: 'none',
                    backgroundColor: '#007bff',
                    textColor: '#ffffff'
                }
            }
        };

        this.templates = [
            {
                id: 'focus-master',
                name: 'Focus Master',
                description: 'Pomodoro timer with task management and progress tracking',
                components: [
                    { type: 'pomodoro-timer', id: 'timer-1', props: this.componentDefinitions['pomodoro-timer'].defaultProps },
                    { type: 'todo-list', id: 'tasks-1', props: this.componentDefinitions['todo-list'].defaultProps },
                    { type: 'progress-bar', id: 'progress-1', props: { ...this.componentDefinitions['progress-bar'].defaultProps, goalName: 'Daily Focus Sessions', targetValue: 8, unit: 'sessions' } }
                ]
            },
            {
                id: 'daily-planner',
                name: 'Daily Planner',
                description: 'Complete daily planning with schedule and habit tracking',
                components: [
                    { type: 'text-block', id: 'header-1', props: { ...this.componentDefinitions['text-block'].defaultProps, text: 'My Daily Planner', fontSize: 24, fontWeight: 'bold' } },
                    { type: 'todo-list', id: 'tasks-1', props: this.componentDefinitions['todo-list'].defaultProps },
                    { type: 'habit-tracker', id: 'habits-1', props: this.componentDefinitions['habit-tracker'].defaultProps }
                ]
            },
            {
                id: 'goal-tracker',
                name: 'Goal Tracker',
                description: 'Track progress towards your goals with visual indicators',
                components: [
                    { type: 'text-block', id: 'header-1', props: { ...this.componentDefinitions['text-block'].defaultProps, text: 'Goal Progress', fontSize: 20, fontWeight: 'bold' } },
                    { type: 'progress-bar', id: 'goal-1', props: { ...this.componentDefinitions['progress-bar'].defaultProps, goalName: 'Learn Spanish', targetValue: 100, unit: 'lessons' } },
                    { type: 'progress-bar', id: 'goal-2', props: { ...this.componentDefinitions['progress-bar'].defaultProps, goalName: 'Exercise Weekly', targetValue: 52, unit: 'weeks' } },
                    { type: 'streak-counter', id: 'streak-1', props: this.componentDefinitions['streak-counter'].defaultProps }
                ]
            }
        ];

        // Wait for DOM to be ready
        if (document.readyState === 'loading') {
            document.addEventListener('DOMContentLoaded', () => this.init());
        } else {
            this.init();
        }
    }

    init() {
        this.setupEventListeners();
        this.setupDragAndDrop();
        this.loadFromStorage();
        this.renderCanvas();
        this.addToHistory();
    }

    setupEventListeners() {
        // Navigation
        document.querySelectorAll('[data-nav]').forEach(btn => {
            btn.addEventListener('click', (e) => {
                e.preventDefault();
                this.handleNavigation(e.target.dataset.nav);
            });
        });

        // Canvas actions
        document.getElementById('edit-name').addEventListener('click', () => this.editToolName());
        document.getElementById('undo').addEventListener('click', () => this.undo());
        document.getElementById('redo').addEventListener('click', () => this.redo());
        document.getElementById('preview-mode').addEventListener('click', () => this.togglePreview());

        // Zoom controls
        document.getElementById('zoom-in').addEventListener('click', () => this.zoom(10));
        document.getElementById('zoom-out').addEventListener('click', () => this.zoom(-10));

        // Toolbar actions
        document.getElementById('new-tool').addEventListener('click', () => this.newTool());
        document.getElementById('load-template').addEventListener('click', () => this.showTemplateModal());
        document.getElementById('save-tool').addEventListener('click', () => this.saveTool());
        document.getElementById('publish-tool').addEventListener('click', () => this.publishTool());
        document.getElementById('export-tool').addEventListener('click', () => this.exportTool());

        // Category toggles
        document.querySelectorAll('.category__toggle').forEach(toggle => {
            toggle.addEventListener('click', (e) => {
                e.stopPropagation();
                this.toggleCategory(e.target);
            });
        });

        document.querySelectorAll('.category__header').forEach(header => {
            header.addEventListener('click', (e) => {
                if (e.target.classList.contains('category__toggle')) return;
                this.toggleCategory(header.querySelector('.category__toggle'));
            });
        });

        // Modal events
        document.querySelectorAll('.modal__close, .modal__backdrop').forEach(el => {
            el.addEventListener('click', (e) => {
                if (e.target.classList.contains('modal__backdrop') || e.target.classList.contains('modal__close')) {
                    this.closeModal();
                }
            });
        });

        document.getElementById('modal-cancel').addEventListener('click', () => this.closeModal());
        document.getElementById('modal-save').addEventListener('click', () => this.saveComponentProperties());

        // Auto-save
        setInterval(() => this.autoSave(), 30000);
    }

    setupDragAndDrop() {
        // Make component items draggable and add event listeners
        document.querySelectorAll('.component-item').forEach(item => {
            // Ensure draggable is set
            item.draggable = true;
            
            item.addEventListener('dragstart', (e) => {
                console.log('Drag start:', e.target.dataset.component);
                this.handleDragStart(e);
            });
            
            item.addEventListener('dragend', (e) => {
                console.log('Drag end');
                this.handleDragEnd(e);
            });
            
            // Also add click handler as fallback
            item.addEventListener('click', (e) => {
                const componentType = e.currentTarget.dataset.component;
                if (componentType) {
                    console.log('Click to add component:', componentType);
                    this.addComponent(componentType);
                }
            });
        });

        // Canvas drop zone
        const canvas = document.getElementById('canvas');
        const dropZone = canvas.querySelector('.canvas__drop-zone') || canvas;
        
        [canvas, dropZone].forEach(element => {
            if (element) {
                element.addEventListener('dragover', (e) => {
                    e.preventDefault();
                    e.dataTransfer.dropEffect = 'copy';
                    canvas.classList.add('drag-over');
                });
                
                element.addEventListener('drop', (e) => {
                    e.preventDefault();
                    console.log('Drop event');
                    canvas.classList.remove('drag-over');
                    
                    const componentType = e.dataTransfer.getData('text/plain') || this.draggedComponent;
                    console.log('Dropped component:', componentType);
                    
                    if (componentType && this.componentDefinitions[componentType]) {
                        this.addComponent(componentType);
                    }
                });
                
                element.addEventListener('dragleave', (e) => {
                    if (!element.contains(e.relatedTarget)) {
                        canvas.classList.remove('drag-over');
                    }
                });
            }
        });
    }

    handleDragStart(e) {
        const componentType = e.target.closest('.component-item').dataset.component;
        this.draggedComponent = componentType;
        e.target.classList.add('dragging');
        
        e.dataTransfer.effectAllowed = 'copy';
        e.dataTransfer.setData('text/plain', componentType);
        console.log('Started dragging:', componentType);
    }

    handleDragEnd(e) {
        e.target.classList.remove('dragging');
        // Don't clear draggedComponent immediately as drop event might still need it
        setTimeout(() => {
            this.draggedComponent = null;
        }, 100);
    }

    addComponent(componentType) {
        console.log('Adding component:', componentType);
        
        if (!this.componentDefinitions[componentType]) {
            console.error('Unknown component type:', componentType);
            return;
        }

        const component = {
            type: componentType,
            id: `${componentType}-${Date.now()}`,
            props: { ...this.componentDefinitions[componentType].defaultProps }
        };

        this.currentTool.components.push(component);
        this.addToHistory();
        this.renderCanvas();
        this.updateSaveStatus('unsaved');
        
        console.log('Component added successfully:', component);
    }

    renderCanvas() {
        const canvas = document.querySelector('.canvas__drop-zone');
        
        if (this.currentTool.components.length === 0) {
            canvas.innerHTML = `
                <div class="empty-state">
                    <div class="empty-state__icon">🛠️</div>
                    <h3>Start Building Your Productivity Tool</h3>
                    <p>Drag components from the left sidebar to get started</p>
                </div>
            `;
        } else {
            canvas.innerHTML = this.currentTool.components.map(component => 
                this.renderComponent(component)
            ).join('');
            
            // Add event listeners to rendered components
            this.setupCanvasComponentEvents();
        }

        // Update tool name
        document.getElementById('tool-name').textContent = this.currentTool.name;
    }

    renderComponent(component) {
        const definition = this.componentDefinitions[component.type];
        const isSelected = this.selectedComponent === component.id;
        
        return `
            <div class="canvas-component ${isSelected ? 'selected' : ''}" data-component-id="${component.id}">
                <div class="canvas-component__content">
                    ${this.renderComponentContent(component)}
                </div>
                <div class="canvas-component__handle">
                    <button class="component-handle-btn handle-edit" data-action="edit" title="Edit">✎</button>
                    <button class="component-handle-btn handle-delete" data-action="delete" title="Delete">×</button>
                </div>
            </div>
        `;
    }

    renderComponentContent(component) {
        const { type, props } = component;
        
        switch (type) {
            case 'pomodoro-timer':
                return `
                    <div class="component-pomodoro-timer">
                        <h3>${this.componentDefinitions[type].icon} Pomodoro Timer</h3>
                        <div class="timer-display">${props.workDuration}:00</div>
                        <div class="timer-controls">
                            <button class="btn btn--sm btn--primary">Start</button>
                            <button class="btn btn--sm btn--outline">Reset</button>
                        </div>
                        <p>Work: ${props.workDuration}min | Break: ${props.breakDuration}min</p>
                    </div>
                `;
            
            case 'countdown-timer':
                return `
                    <div class="component-countdown-timer">
                        <h3>${this.componentDefinitions[type].icon} Countdown Timer</h3>
                        <div class="timer-display">${props.duration}:00</div>
                        <div class="timer-controls">
                            <button class="btn btn--sm btn--primary">Start</button>
                            <button class="btn btn--sm btn--outline">Reset</button>
                        </div>
                    </div>
                `;
            
            case 'focus-timer':
                return `
                    <div class="component-focus-timer">
                        <h3>${this.componentDefinitions[type].icon} Focus Session</h3>
                        <div class="timer-display">${props.duration}:00</div>
                        <div class="timer-controls">
                            <button class="btn btn--sm btn--primary">Focus</button>
                            <button class="btn btn--sm btn--outline">Break</button>
                        </div>
                    </div>
                `;
            
            case 'todo-list':
                return `
                    <div class="component-todo-list">
                        <h3>${this.componentDefinitions[type].icon} To-Do List</h3>
                        <div class="todo-item">
                            <input type="checkbox" class="todo-checkbox">
                            <span>Complete project presentation</span>
                        </div>
                        <div class="todo-item">
                            <input type="checkbox" class="todo-checkbox" checked>
                            <span style="text-decoration: line-through; opacity: 0.6;">Review meeting notes</span>
                        </div>
                        <div class="todo-item">
                            <input type="checkbox" class="todo-checkbox">
                            <span>Call client about requirements</span>
                        </div>
                        <button class="btn btn--sm btn--outline" style="margin-top: 12px;">+ Add Task</button>
                    </div>
                `;
            
            case 'habit-tracker':
                return `
                    <div class="component-habit-tracker">
                        <h3>${this.componentDefinitions[type].icon} Habit Tracker</h3>
                        <div style="margin: 12px 0;">
                            <strong>${props.habits[0] || 'Daily Habit'}</strong>
                        </div>
                        <div class="habit-grid">
                            ${Array.from({ length: 14 }, (_, i) => `
                                <div class="habit-day ${i < 8 ? 'completed' : ''}">${i + 1}</div>
                            `).join('')}
                        </div>
                        <div style="margin-top: 12px; font-size: 14px; color: var(--color-text-secondary);">
                            Current streak: 8 days 🔥
                        </div>
                    </div>
                `;
            
            case 'streak-counter':
                return `
                    <div class="component-streak-counter" style="text-align: center; background: var(--color-bg-4); padding: 24px; border-radius: 12px;">
                        <h3>${this.componentDefinitions[type].icon} ${props.habitName}</h3>
                        <div style="font-size: 36px; font-weight: bold; color: var(--color-primary); margin: 16px 0;">
                            ${props.currentStreak} days
                        </div>
                        <p>Longest streak: ${props.longestStreak} days</p>
                        <button class="btn btn--sm btn--primary">Mark Complete</button>
                    </div>
                `;
            
            case 'progress-bar':
                const percentage = Math.min(100, Math.round((props.currentValue / props.targetValue) * 100));
                return `
                    <div class="component-progress-bar" style="background: var(--color-bg-5); padding: 16px; border-radius: 12px;">
                        <h3>${this.componentDefinitions[type].icon} ${props.goalName}</h3>
                        <div style="background: var(--color-secondary); border-radius: 8px; height: 20px; margin: 12px 0; overflow: hidden;">
                            <div style="background: var(--color-primary); height: 100%; width: ${percentage}%; transition: width 0.3s ease;"></div>
                        </div>
                        <div style="display: flex; justify-content: space-between; font-size: 14px;">
                            <span>${props.currentValue} ${props.unit}</span>
                            <span>${percentage}%</span>
                            <span>${props.targetValue} ${props.unit}</span>
                        </div>
                    </div>
                `;
            
            case 'text-block':
                return `
                    <div class="component-text-block">
                        <div style="font-size: ${props.fontSize}px; text-align: ${props.textAlign}; font-weight: ${props.fontWeight};">
                            ${props.text}
                        </div>
                    </div>
                `;
            
            case 'button':
                return `
                    <div class="component-button" style="text-align: center;">
                        <button class="btn" style="background: ${props.backgroundColor}; color: ${props.textColor};">
                            ${props.text}
                        </button>
                    </div>
                `;
            
            default:
                return `
                    <div class="component-placeholder">
                        <h3>${this.componentDefinitions[type]?.icon || '❓'} ${this.componentDefinitions[type]?.name || type}</h3>
                        <p>Component preview</p>
                    </div>
                `;
        }
    }

    setupCanvasComponentEvents() {
        document.querySelectorAll('.canvas-component').forEach(el => {
            el.addEventListener('click', (e) => {
                e.stopPropagation();
                this.selectComponent(el.dataset.componentId);
            });
        });

        document.querySelectorAll('.component-handle-btn').forEach(btn => {
            btn.addEventListener('click', (e) => {
                e.stopPropagation();
                const componentId = e.target.closest('.canvas-component').dataset.componentId;
                const action = e.target.dataset.action;
                
                if (action === 'edit') {
                    this.editComponent(componentId);
                } else if (action === 'delete') {
                    this.deleteComponent(componentId);
                }
            });
        });

        // Deselect when clicking canvas
        document.getElementById('canvas').addEventListener('click', (e) => {
            if (e.target.id === 'canvas' || e.target.classList.contains('canvas__drop-zone') || e.target.classList.contains('empty-state')) {
                this.selectComponent(null);
            }
        });
    }

    selectComponent(componentId) {
        this.selectedComponent = componentId;
        this.renderCanvas();
        this.updatePropertiesPanel();
    }

    editComponent(componentId) {
        const component = this.currentTool.components.find(c => c.id === componentId);
        if (component) {
            this.tempComponentProps = { ...component.props };
            this.showComponentModal(component);
        }
    }

    deleteComponent(componentId) {
        if (confirm('Are you sure you want to delete this component?')) {
            this.currentTool.components = this.currentTool.components.filter(c => c.id !== componentId);
            this.selectedComponent = null;
            this.addToHistory();
            this.renderCanvas();
            this.updatePropertiesPanel();
        }
    }

    updatePropertiesPanel() {
        const panel = document.getElementById('properties-panel');
        
        if (!this.selectedComponent) {
            panel.innerHTML = `
                <div class="no-selection">
                    <div class="no-selection__icon">👆</div>
                    <p>Select a component to edit its properties</p>
                </div>
            `;
            return;
        }

        const component = this.currentTool.components.find(c => c.id === this.selectedComponent);
        if (!component) return;

        const definition = this.componentDefinitions[component.type];
        panel.innerHTML = `
            <div class="property-group">
                <h4>Component Info</h4>
                <div class="property-field">
                    <label>Type</label>
                    <input type="text" class="form-control" value="${definition.name}" readonly>
                </div>
                <div class="property-field">
                    <label>ID</label>
                    <input type="text" class="form-control" value="${component.id}" readonly>
                </div>
            </div>
            <div class="property-group">
                <h4>Properties</h4>
                ${this.renderPropertyFields(component)}
            </div>
            <div class="property-group">
                <button class="btn btn--primary btn--full-width" onclick="app.editComponent('${component.id}')">
                    Advanced Settings
                </button>
            </div>
        `;
    }

    renderPropertyFields(component) {
        const commonProps = ['name', 'text', 'duration', 'workDuration', 'goalName', 'habitName'];
        const relevantProps = Object.keys(component.props).filter(key => 
            commonProps.includes(key)
        );

        return relevantProps.map(key => {
            const value = component.props[key];
            return `
                <div class="property-field">
                    <label>${this.formatPropertyName(key)}</label>
                    <input 
                        type="${typeof value === 'number' ? 'number' : 'text'}" 
                        class="form-control" 
                        value="${value}"
                        onchange="app.updateComponentProperty('${component.id}', '${key}', this.value)"
                    >
                </div>
            `;
        }).join('');
    }

    formatPropertyName(key) {
        return key.replace(/([A-Z])/g, ' $1').replace(/^./, str => str.toUpperCase());
    }

    updateComponentProperty(componentId, property, value) {
        const component = this.currentTool.components.find(c => c.id === componentId);
        if (component) {
            // Convert to appropriate type
            if (typeof component.props[property] === 'number') {
                value = parseFloat(value) || 0;
            }
            
            component.props[property] = value;
            this.renderCanvas();
            this.updateSaveStatus('unsaved');
        }
    }

    showComponentModal(component) {
        const modal = document.getElementById('component-modal');
        const title = document.getElementById('modal-component-title');
        const body = document.getElementById('modal-component-body');

        title.textContent = `${this.componentDefinitions[component.type].name} Settings`;
        body.innerHTML = this.renderComponentModalContent(component);

        modal.classList.remove('hidden');
    }

    renderComponentModalContent(component) {
        const props = component.props;
        
        return Object.keys(props).map(key => {
            const value = props[key];
            const type = typeof value;
            
            if (type === 'boolean') {
                return `
                    <div class="form-group">
                        <label class="form-label">${this.formatPropertyName(key)}</label>
                        <label style="display: flex; align-items: center; gap: 8px;">
                            <input 
                                type="checkbox" 
                                ${value ? 'checked' : ''}
                                onchange="app.tempComponentProps['${key}'] = this.checked"
                            >
                            <span>Enable ${this.formatPropertyName(key).toLowerCase()}</span>
                        </label>
                    </div>
                `;
            } else if (type === 'number') {
                return `
                    <div class="form-group">
                        <label class="form-label">${this.formatPropertyName(key)}</label>
                        <input 
                            type="number" 
                            class="form-control" 
                            value="${value}"
                            onchange="app.tempComponentProps['${key}'] = parseFloat(this.value)"
                        >
                    </div>
                `;
            } else if (Array.isArray(value)) {
                return `
                    <div class="form-group">
                        <label class="form-label">${this.formatPropertyName(key)}</label>
                        <textarea 
                            class="form-control" 
                            rows="3"
                            placeholder="Enter items separated by commas"
                            onchange="app.tempComponentProps['${key}'] = this.value.split(',').map(s => s.trim()).filter(s => s)"
                        >${value.join(', ')}</textarea>
                    </div>
                `;
            } else {
                return `
                    <div class="form-group">
                        <label class="form-label">${this.formatPropertyName(key)}</label>
                        <input 
                            type="text" 
                            class="form-control" 
                            value="${value}"
                            onchange="app.tempComponentProps['${key}'] = this.value"
                        >
                    </div>
                `;
            }
        }).join('');
    }

    saveComponentProperties() {
        if (this.selectedComponent && this.tempComponentProps) {
            const component = this.currentTool.components.find(c => c.id === this.selectedComponent);
            if (component) {
                Object.assign(component.props, this.tempComponentProps);
                this.addToHistory();
                this.renderCanvas();
                this.updatePropertiesPanel();
            }
        }
        this.closeModal();
    }

    showTemplateModal() {
        const modal = document.getElementById('template-modal');
        const grid = document.getElementById('template-grid');

        grid.innerHTML = this.templates.map(template => `
            <div class="template-card" onclick="app.loadTemplate('${template.id}')">
                <h4>${template.name}</h4>
                <p>${template.description}</p>
                <div class="template-components">
                    ${template.components.map(comp => 
                        `<span class="template-component-tag">${this.componentDefinitions[comp.type]?.name || comp.type}</span>`
                    ).join('')}
                </div>
            </div>
        `).join('');

        modal.classList.remove('hidden');
    }

    loadTemplate(templateId) {
        const template = this.templates.find(t => t.id === templateId);
        if (template) {
            this.currentTool.name = template.name;
            this.currentTool.components = JSON.parse(JSON.stringify(template.components));
            this.selectedComponent = null;
            this.addToHistory();
            this.renderCanvas();
            this.updatePropertiesPanel();
        }
        this.closeModal();
    }

    closeModal() {
        document.querySelectorAll('.modal').forEach(modal => {
            modal.classList.add('hidden');
        });
        this.tempComponentProps = {};
    }

    toggleCategory(toggle) {
        const content = toggle.closest('.component-category').querySelector('.category__content');
        const isCollapsed = content.classList.contains('collapsed');
        
        if (isCollapsed) {
            content.classList.remove('collapsed');
            toggle.textContent = '−';
        } else {
            content.classList.add('collapsed');
            toggle.textContent = '+';
        }
    }

    editToolName() {
        const newName = prompt('Enter tool name:', this.currentTool.name);
        if (newName && newName.trim()) {
            this.currentTool.name = newName.trim();
            document.getElementById('tool-name').textContent = this.currentTool.name;
            this.updateSaveStatus('unsaved');
        }
    }

    newTool() {
        if (confirm('Create a new tool? Unsaved changes will be lost.')) {
            this.currentTool = {
                id: `tool-${Date.now()}`,
                name: 'Untitled Tool',
                components: [],
                created: new Date().toISOString()
            };
            this.selectedComponent = null;
            this.history = [];
            this.historyIndex = -1;
            this.renderCanvas();
            this.updatePropertiesPanel();
        }
    }

    saveTool() {
        this.saveToStorage();
        this.updateSaveStatus('saved');
        alert('Tool saved successfully!');
    }

    publishTool() {
        this.saveToStorage();
        const shareUrl = `${window.location.origin}${window.location.pathname}?tool=${this.currentTool.id}`;
        
        if (navigator.share) {
            navigator.share({
                title: this.currentTool.name,
                text: 'Check out my custom productivity tool!',
                url: shareUrl
            });
        } else {
            navigator.clipboard.writeText(shareUrl).then(() => {
                alert('Share link copied to clipboard!');
            }).catch(() => {
                prompt('Copy this share link:', shareUrl);
            });
        }
    }

    exportTool() {
        const data = JSON.stringify(this.currentTool, null, 2);
        const blob = new Blob([data], { type: 'application/json' });
        const url = URL.createObjectURL(blob);
        
        const a = document.createElement('a');
        a.href = url;
        a.download = `${this.currentTool.name.replace(/[^a-z0-9]/gi, '_').toLowerCase()}.json`;
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
        URL.revokeObjectURL(url);
    }

    zoom(delta) {
        this.zoomLevel = Math.max(50, Math.min(200, this.zoomLevel + delta));
        const canvas = document.getElementById('canvas');
        canvas.style.transform = `scale(${this.zoomLevel / 100})`;
        document.querySelector('.zoom-level').textContent = `${this.zoomLevel}%`;
    }

    addToHistory() {
        this.history = this.history.slice(0, this.historyIndex + 1);
        this.history.push(JSON.stringify(this.currentTool));
        this.historyIndex++;
        
        if (this.history.length > 50) {
            this.history.shift();
            this.historyIndex--;
        }
    }

    undo() {
        if (this.historyIndex > 0) {
            this.historyIndex--;
            this.currentTool = JSON.parse(this.history[this.historyIndex]);
            this.selectedComponent = null;
            this.renderCanvas();
            this.updatePropertiesPanel();
        }
    }

    redo() {
        if (this.historyIndex < this.history.length - 1) {
            this.historyIndex++;
            this.currentTool = JSON.parse(this.history[this.historyIndex]);
            this.selectedComponent = null;
            this.renderCanvas();
            this.updatePropertiesPanel();
        }
    }

    togglePreview() {
        const canvas = document.getElementById('canvas');
        const isPreview = canvas.classList.contains('preview-mode');
        
        if (isPreview) {
            canvas.classList.remove('preview-mode');
            document.getElementById('preview-mode').textContent = '👁️ Preview';
        } else {
            canvas.classList.add('preview-mode');
            document.getElementById('preview-mode').textContent = '✎ Edit';
        }
    }

    updateSaveStatus(status) {
        const indicator = document.getElementById('save-status');
        indicator.className = `status-indicator ${status}`;
        
        switch (status) {
            case 'saving':
                indicator.textContent = 'Saving...';
                break;
            case 'saved':
                indicator.textContent = 'Saved';
                break;
            case 'unsaved':
                indicator.textContent = 'Unsaved changes';
                break;
            default:
                indicator.textContent = 'Auto-saved';
        }
    }

    autoSave() {
        if (this.currentTool.components.length > 0) {
            this.saveToStorage();
            this.updateSaveStatus('auto-saved');
        }
    }

    saveToStorage() {
        try {
            localStorage.setItem(`productivity-tool-${this.currentTool.id}`, JSON.stringify(this.currentTool));
            localStorage.setItem('productivity-tool-current', this.currentTool.id);
        } catch (e) {
            console.warn('Could not save to localStorage:', e);
        }
    }

    loadFromStorage() {
        try {
            const currentId = localStorage.getItem('productivity-tool-current');
            if (currentId) {
                const saved = localStorage.getItem(`productivity-tool-${currentId}`);
                if (saved) {
                    this.currentTool = JSON.parse(saved);
                }
            }
        } catch (e) {
            console.warn('Could not load from localStorage:', e);
        }
    }

    handleNavigation(section) {
        // Simple navigation handling
        switch (section) {
            case 'home':
                // Already on home
                break;
            case 'my-tools':
                alert('My Tools feature coming soon!');
                break;
            case 'templates':
                this.showTemplateModal();
                break;
            case 'help':
                alert('Help: Drag components from the left sidebar to the canvas, click to select and edit properties. Use the Templates button to load pre-built tools.');
                break;
        }
    }
}

// Initialize the application
const app = new ProductivityToolBuilder();

// Make app globally available for onclick handlers
window.app = app;